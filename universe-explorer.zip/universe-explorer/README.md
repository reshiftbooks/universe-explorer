# Universe Explorer — Interactive 3D Space Visualization

A fully interactive, high-fidelity 3D universe explorer built with **HTML5, CSS3, vanilla JavaScript and Three.js**. It runs entirely in the browser as a pure static site — no backend, no build step — and is ready for **GitHub Pages**.

## Features

| Module | What you get |
| --- | --- |
| Solar System | Sun + all 8 planets in their real orbital order, real relative orbital speed ratios, orbit lines, click any planet for a live data panel |
| Planet Information | Diameter, mass, gravity, temperature, distance from the Sun, orbital & rotation periods, atmosphere composition and science facts — real NASA-based values, clearly separated from the compressed visual scale |
| Earth Explorer | Procedural continents & oceans, animated clouds, atmospheric glow, rotating day/night terminator, 23.5° axial tilt, orbiting Moon |
| Black Hole | Accretion disk with a custom GLSL shader (differential rotation, turbulent streaks, temperature gradient, Doppler-style brightness), photon ring, event horizon — clearly labelled as a stylized simulation |
| Galaxy | Procedural barred-spiral Milky Way with ~22,000 star particles, nebula clouds and a bright core |
| Space Missions | Apollo 11, Voyager 1 & 2, Hubble, James Webb, Perseverance & Ingenuity — verified mission facts |
| Interactive Controls | Play/pause, 0.1–20× speed slider, reset view, fullscreen, hover tooltips, click-to-select with camera focus, keyboard shortcuts — every button works |

Interactive controls and shortcuts: `Space` = play/pause, `R` = reset view, `F` = fullscreen, `Esc` = close panel. Mouse / touch: drag to rotate, scroll / pinch to zoom, click a planet to select it.

## Project structure

```
universe-explorer/
├── index.html            # app shell: top nav, info panel, controls, overlays
├── css/
│   └── style.css         # dark space theme, glass panels, responsive layout
├── js/
│   ├── data.js           # NASA-based planetary / mission data (real values)
│   ├── textures.js       # procedural canvas textures (no image files needed)
│   ├── main.js           # app controller: rendering, picking, UI, errors
│   └── scenes/
│       ├── solar.js      # Solar System module
│       ├── earth.js      # Earth module
│       ├── blackhole.js  # Black Hole module
│       ├── galaxy.js     # Galaxy module
│       └── missions.js   # Space Missions module
└── README.md
```

Three.js (v0.128.0) is loaded from a CDN (`cdn.jsdelivr.net`) — nothing to install.

## Run locally

**Option A — simplest:** make sure you are online (Three.js comes from a CDN), then double-click `index.html`. That's it.

**Option B — local server (recommended):**
```bash
cd universe-explorer
python3 -m http.server 8000
# open http://localhost:8000 in your browser
```

**Option C — VS Code:** install the *Live Server* extension, right-click `index.html` → *Open with Live Server*.

## Upload to GitHub

1. Create a new (public) repository on [github.com](https://github.com), e.g. `universe-explorer`. Do **not** add a README via the web wizard if you plan to push this folder as-is.
2. Then either:
   - **Web upload:** on the repo page click *uploading an existing file*, drag the whole contents of the `universe-explorer` folder (keep the folder structure: `index.html`, `css/`, `js/`), commit; **or**
   - **Git CLI:**
     ```bash
     cd universe-explorer
     git init
     git add .
     git commit -m "Universe Explorer - initial release"
     git branch -M main
     git remote add origin https://github.com/YOUR_USERNAME/universe-explorer.git
     git push -u origin main
     ```

## Deploy on GitHub Pages

1. Open your repo → **Settings** → **Pages** (left sidebar).
2. Under *Build and deployment*, set **Source = Deploy from a branch**.
3. Choose branch **main**, folder **/(root)**, click **Save**.
4. Wait 1–2 minutes; GitHub shows the live URL, typically:
   `https://YOUR_USERNAME.github.io/universe-explorer/`
5. Open it — the site is now live. Every future push to `main` redeploys automatically.

> Tip: if the page looks unstyled after deploy, hard-refresh (Ctrl/Cmd+Shift+R) — GitHub Pages can serve a cached copy for a minute.

## Data sources & honest-science notes

- Planetary values are consistent with NASA's planetary fact sheets (nssdc.gsfc.nasa.gov).
- Mission facts come from NASA/ESA public mission pages.
- The 3D view **compresses sizes and distances** so all planets stay visible; every info panel shows a clear scale notice, and the black hole view is explicitly labelled as a stylized simulation. Real data and visual approximations are never mixed silently.

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| "Something went wrong" box on load | You are offline or a CDN request failed — check internet, reload |
| Black screen, no stars | WebGL may be disabled — use a current Chrome/Firefox/Edge/Safari |
| Blank page on `file://` | Rare browser restrictions — use Option B/C (a local server) |
| Slow on old phones | Reduce the browser window size, or lower device pixel ratio — the app already caps it at 2× |
